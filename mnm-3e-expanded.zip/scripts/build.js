const fs = require('fs-extra');
const yaml = require('js-yaml');
const path = require('path');

// M&M 3e French System Translation Mappings
const translationMap = {
  type: {
    'power': 'pouvoir',
    'advantage': 'avantage'
  },
  action: {
    'standard': 'simple',
    'move': 'mouvement',
    'free': 'libre',
    'reaction': 'reaction',
    'none': 'aucune'
  },
  range: {
    'personal': 'personnelle',
    'close': 'contact',
    'ranged': 'a distance',
    'perception': 'perception',
    'rank': 'rang'
  },
  duration: {
    'instant': 'instantane',
    'sustained': 'maintenu',
    'continuous': 'continu',
    'concentration': 'concentration',
    'permanent': 'permanent'
  }
};

async function build() {
  const srcDir = path.join(__dirname, '../src/powers');
  const distDir = path.join(__dirname, '../packs');
  const outFile = path.join(distDir, 'powers.db');

  // Ensure output directory exists
  await fs.ensureDir(distDir);

  const files = await fs.readdir(srcDir);
  const items = [];

  for (const file of files) {
    if (file.endsWith('.yaml')) {
      const content = await fs.readFile(path.join(srcDir, file), 'utf8');
      const data = yaml.load(content);

      // Map YAML to Foundry M&M 3e JSON structure
      const foundryItem = {
        name: data.name,
        type: translationMap.type[data.type] || data.type,
        img: `systems/mutants-and-masterminds-3e/assets/icons/${translationMap.type[data.type] || 'pouvoir'}.svg`,
        system: {
          activate: true,
          special: translationMap.action[data.action] || data.action,
          type: 'attaque',
          action: translationMap.action[data.action] || data.action,
          portee: translationMap.range[data.range] || data.range,
          duree: translationMap.duration[data.duration] || data.duration,
          effets: data.mechanics,
          notes: data.description,
          cout: {
            rang: data.rank || 0,
            parrang: data.cost_per_rank || 1,
            total: (data.rank || 0) * (data.cost_per_rank || 1)
          }
        },
        _id: Math.random().toString(36).substring(2, 18) // Generate a random ID
      };

      items.push(JSON.stringify(foundryItem));
    }
  }

  // Foundry database (.db) files are just a text file with one JSON per line
  await fs.writeFile(outFile, items.join('\n'));
  console.log(`Successfully built powers.db with ${items.length} items.`);
}

build().catch(err => console.error(err));
